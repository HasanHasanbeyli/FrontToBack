﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Teacher.DAL;
using Teacher.ViewModels;

namespace Teacher.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            HomeVM homeVM = new HomeVM
            {
                Sliders = _db.Sliders,
                NoticeBoards = _db.NoticeBoards,
                Boards = _db.Boards,
                AboutUs = _db.AboutUs.FirstOrDefault(),
                CoursesOffers = _db.CoursesOffers,
                UpcommingEvents = _db.UpcommingEvents,
                Testimonials = _db.Testimonials.FirstOrDefault(),
                FromBlogs=_db.FromBlogs,
                HomePageBio=_db.HomePageBios.FirstOrDefault()
            };
            return View(homeVM);
        }
    }
}
