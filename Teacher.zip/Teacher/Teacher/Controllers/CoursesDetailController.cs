﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Teacher.DAL;
using Teacher.ViewModels;

namespace Teacher.Controllers
{
    public class CoursesDetailController : Controller
    {
        private readonly AppDbContext _db;
        public CoursesDetailController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            CoursesDetailVM coursesDetailVM = new CoursesDetailVM
            {
                CourseDetailImage = _db.CourseDetailImages.FirstOrDefault(),
                CourseDetailDescriptions=_db.courseDetailDescriptions,
                CourseDetailTitle=_db.CourseDetailTitles.FirstOrDefault(),
                CourseDetailFeatures=_db.CourseDetailFeatures,
                CourseDetailCategories=_db.CourseDetailCategories,
                CourseDetailTheme=_db.CourseDetailThemes.FirstOrDefault(),
                CourseDetailLatestPosts=_db.CourseDetailLatestPosts,
                CourseDetailTags=_db.CourseDetailTags
            };
            return View(coursesDetailVM);
        }
    }
}
