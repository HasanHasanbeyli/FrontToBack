﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Teacher.DAL;
using Teacher.ViewModels;

namespace Teacher.Controllers
{
    public class AboutController : Controller
    {
        private readonly AppDbContext _db;
        public AboutController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            AboutVM aboutVM = new AboutVM
            {
                WelcomeEduHome = _db.WelcomeEduHomes.FirstOrDefault(),
                TeacherDetails=_db.TeacherDetails,
                VideoTour=_db.VideoTours.FirstOrDefault()
            };
            return View(aboutVM);
        }
    }
}
