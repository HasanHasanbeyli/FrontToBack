﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Teacher.DAL;
using Teacher.ViewModels;

namespace Teacher.Controllers
{
    public class EventDetailsController : Controller
    {
        private readonly AppDbContext _db;
        public EventDetailsController( AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            EventDetailVM eventDetailVM = new EventDetailVM
            {
                EventDetailImage=_db.EventDetailImages.FirstOrDefault(),
                EventDetailSpeakers=_db.EventDetailSpeakers
            };
            return View(eventDetailVM);
        }
    }
}
