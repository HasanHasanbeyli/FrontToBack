﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Teacher.Migrations
{
    public partial class AddColumnTitleToFromBlog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Title",
                table: "FromBlogs",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Title",
                table: "FromBlogs");
        }
    }
}
