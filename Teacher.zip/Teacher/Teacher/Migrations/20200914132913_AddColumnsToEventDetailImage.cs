﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Teacher.Migrations
{
    public partial class AddColumnsToEventDetailImage : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Adres",
                table: "EventDetailImages",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "EventDetailImages",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Time",
                table: "EventDetailImages",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Title",
                table: "EventDetailImages",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Adres",
                table: "EventDetailImages");

            migrationBuilder.DropColumn(
                name: "Description",
                table: "EventDetailImages");

            migrationBuilder.DropColumn(
                name: "Time",
                table: "EventDetailImages");

            migrationBuilder.DropColumn(
                name: "Title",
                table: "EventDetailImages");
        }
    }
}
