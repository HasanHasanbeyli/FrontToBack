﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.Models;

namespace Teacher.DAL
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) :base(options)
        {
        }
        public DbSet<Slider> Sliders { get; set; }
        public DbSet<NoticeBoard> NoticeBoards { get; set; }
        public DbSet<Board> Boards { get; set; }
        public DbSet<AboutUs> AboutUs { get; set; }
        public DbSet<CoursesOffer> CoursesOffers { get; set; }
        public DbSet<UpcommingEvents> UpcommingEvents { get; set; }
        public DbSet<Testimonial> Testimonials { get; set; }
        public DbSet<FromBlog> FromBlogs { get; set; }
        public DbSet<Bio> Bios { get; set; }
        public DbSet<HomePageBio> HomePageBios { get; set; }
        public DbSet<WelcomeEduHome> WelcomeEduHomes { get; set; }
        public DbSet<TeacherDetail> TeacherDetails { get; set; }
        public DbSet<VideoTour> VideoTours { get; set; }
        public DbSet<Courses> Courses { get; set; }
        public DbSet<CourseDetailImage> CourseDetailImages { get; set; }
        public DbSet<CourseDetailDescription> courseDetailDescriptions { get; set; }
        public DbSet<CourseDetailTitle> CourseDetailTitles { get; set; }
        public DbSet<CourseDetailFeatures> CourseDetailFeatures { get; set; }
        public DbSet<CourseDetailCategory> CourseDetailCategories { get; set; }
        public DbSet<CourseDetailTheme> CourseDetailThemes { get; set; }
        public DbSet<CourseDetailLatestPost> CourseDetailLatestPosts { get; set; }
        public DbSet<CourseDetailTags> CourseDetailTags { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<EventDetailImage> EventDetailImages { get; set; }
        public DbSet<EventDetailSpeakers> EventDetailSpeakers { get; set; }
    }
}
