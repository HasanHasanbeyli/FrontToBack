﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.DAL;
using Teacher.Models;

namespace Teacher.ViewComponents
{
    public class TestimonialViewComponent:ViewComponent
    {
        private readonly AppDbContext _db;
        public TestimonialViewComponent(AppDbContext db)
        {
            _db = db;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            Testimonial model = _db.Testimonials.FirstOrDefault();
            return View(await Task.FromResult(model));
        } 
    }
}
