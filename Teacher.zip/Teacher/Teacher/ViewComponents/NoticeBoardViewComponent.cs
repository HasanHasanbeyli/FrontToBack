﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.DAL;
using Teacher.Models;

namespace Teacher.ViewComponents
{
    public class NoticeBoardViewComponent:ViewComponent
    {
        private readonly AppDbContext _db;
        public NoticeBoardViewComponent(AppDbContext db)
        {
            _db = db;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            List<NoticeBoard> model = _db.NoticeBoards.ToList();
            return View(await Task.FromResult(model));
        }
    }
}
