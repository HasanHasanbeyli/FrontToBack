﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.Models;

namespace Teacher.ViewModels
{
    public class CoursesDetailVM
    {
        public CourseDetailImage CourseDetailImage { get; set; }
        public IEnumerable<CourseDetailDescription> CourseDetailDescriptions { get; set; }
        public CourseDetailTitle CourseDetailTitle { get; set; }
        public IEnumerable<CourseDetailFeatures> CourseDetailFeatures { get; set; }
        public IEnumerable<CourseDetailCategory> CourseDetailCategories { get; set; }
        public CourseDetailTheme CourseDetailTheme { get; set; }
        public IEnumerable<CourseDetailLatestPost> CourseDetailLatestPosts { get; set; }
        public IEnumerable<CourseDetailTags> CourseDetailTags { get; set; }
    }
}
