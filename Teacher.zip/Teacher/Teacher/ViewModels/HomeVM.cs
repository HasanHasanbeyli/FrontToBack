﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.Models;

namespace Teacher.ViewModels
{
    public class HomeVM
    {
        public IEnumerable<Slider> Sliders { get; set; }
        public AboutUs AboutUs { get; set; }
        public IEnumerable<NoticeBoard> NoticeBoards { get; set; }
        public IEnumerable<CoursesOffer> CoursesOffers { get; set; }
        public IEnumerable<UpcommingEvents> UpcommingEvents { get; set; }
        public Testimonial Testimonials { get; set; }
        public IEnumerable<FromBlog> FromBlogs { get; set; }
        public HomePageBio HomePageBio { get; set; }
        public IEnumerable<Board> Boards { get; set; }
    }
}
