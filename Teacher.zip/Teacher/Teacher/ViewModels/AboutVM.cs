﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.Models;

namespace Teacher.ViewModels
{
    public class AboutVM
    {
        public WelcomeEduHome WelcomeEduHome { get; set; }
        public IEnumerable<TeacherDetail> TeacherDetails { get; set; }
        public VideoTour VideoTour { get; set; }
    }
}
