﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.Models;

namespace Teacher.ViewModels
{
    public class EventDetailVM
    {
        public EventDetailImage EventDetailImage { get; set; }
        public IEnumerable<EventDetailSpeakers> EventDetailSpeakers { get; set; }
    }
}
