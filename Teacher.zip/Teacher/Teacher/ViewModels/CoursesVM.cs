﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teacher.Models;

namespace Teacher.ViewModels
{
    public class CoursesVM
    {
        public IEnumerable<Courses> Courses { get; set; }
    }
}
