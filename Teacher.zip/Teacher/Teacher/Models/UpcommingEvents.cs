﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Teacher.Models
{
    public class UpcommingEvents
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int Day { get; set; }
        public string Month { get; set; }
        public string Hour { get; set; }
        public string Location { get; set; }
    }
}
