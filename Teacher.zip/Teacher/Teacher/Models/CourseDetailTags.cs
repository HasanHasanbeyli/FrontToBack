﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Teacher.Models
{
    public class CourseDetailTags
    {
        public int Id { get; set; }
        public string Tags { get; set; }
    }
}
