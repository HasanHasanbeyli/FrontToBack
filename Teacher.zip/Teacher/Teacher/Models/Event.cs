﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Teacher.Models
{
    public class Event
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Time { get; set; }
        public int Day { get; set; }
        public string Month { get; set; }
        public string Image { get; set; }
        public string Adress { get; set; }
    }
}
